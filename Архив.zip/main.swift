//
//  main.swift
//  test771
//
//  Created by user on 20.07.2020.
//  Copyright © 2020 kochnev Nikita. All rights reserved.
//

import Foundation

print("Hello, World!")

var a = 45
var b = 66
var c = a + b

print (c)
